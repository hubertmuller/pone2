package com.pingidentity.authenticatorsampleapp.fragments;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.pingidentity.authenticatorsampleapp.BuildConfig;
import com.pingidentity.authenticatorsampleapp.R;
import com.pingidentity.authenticatorsampleapp.adapters.SideMenuAdapter;
import com.pingidentity.authenticatorsampleapp.adapters.UsersAdapter;
import com.pingidentity.authenticatorsampleapp.managers.PreferencesManager;
import com.pingidentity.authenticatorsampleapp.models.User;
import com.pingidentity.authenticatorsampleapp.util.UserInterfaceUtil;
import com.pingidentity.authenticatorsampleapp.viewmodels.NetworkViewModel;
import com.pingidentity.authenticatorsampleapp.views.OneTimePasscodeView;
import com.pingidentity.pingidsdkv2.PingOne;
import com.pingidentity.pingidsdkv2.PingOneSDKError;

import org.json.JSONObject;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpCookie;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;



import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

import okhttp3.JavaNetCookieJar;
import okhttp3.MediaType;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.X509TrustManager;

/**
 * A simple {@link Fragment} subclass.
 */
public class MainFragment extends Fragment implements UsersAdapter.AdapterSaveCallback, OneTimePasscodeView.PassCodeDataProvider {

    private final static org.slf4j.Logger logger = LoggerFactory.getLogger(MainFragment.class);

    private DrawerLayout mDrawerLayout;
    private ProgressBar progressBar;
    private TextView notificationSliderTextView;
    private TextView passiveAuth;

    private ListView userlist;


    private OneTimePasscodeView progressView;

    private LinkedHashMap<String, Pair<String, String>> localUsersArray;
    private ArrayList<User> usersArrayList = new ArrayList<>();
    private UsersAdapter adapter;
    private boolean shouldRetryPasscode = true;
    private boolean otpAnimationEnabled = true;

    private Context context;

//changes I made to us PF with silent push
    private String flowID="";
    private String PFCookieValue ="";
    private String mobilePayload = "";
    private String Status ="";
    private String p1username ="";



    public MainFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_main, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        mDrawerLayout = view.findViewById(R.id.side_menu_drawer);
        progressBar = view.findViewById(R.id.progress_bar_get_info);
        progressView = view.findViewById(R.id.passcode_view);

        Button silentPush = view.findViewById(R.id.btnAuthenticate);

        passiveAuth = view.findViewById(R.id.txvpassive);



        userlist = view.findViewById(R.id.list_view_users);


        userlist.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {

                getp1Username();
            }
        });




        silentPush.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                authorize();
            }
        });

        Button button = view.findViewById(R.id.button_menu);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDrawer();
            }
        });
        populateUsersView(view);
        populateNewButton(view);
        populateMenuView(view);
        populateSupportIdView(view);
        populateVersionView(view);
        populateErrorSliderView(view);

        NetworkViewModel networkViewModel = new ViewModelProvider(requireActivity()).get(NetworkViewModel.class);
        networkViewModel.getNetwork().observe(requireActivity(), aBoolean -> UserInterfaceUtil.handleNetworkChange(aBoolean, requireContext(), notificationSliderTextView));

        final PreferencesManager preferencesManager = new PreferencesManager();
        localUsersArray = preferencesManager.getUsersList(requireContext());
        if (localUsersArray == null){
            localUsersArray = new LinkedHashMap<>();
        }
        progressBar.setVisibility(View.VISIBLE);
        final View innerView = view;
        PingOne.getInfo(requireContext(), (jsonObject, pingOneSDKError) -> {
            if (jsonObject!=null){
                usersArrayList.clear();
                JsonArray usersArray = jsonObject.getAsJsonArray("users");
                if (usersArray.size()==0){
                    //last user was unpaired from the server
                    preferencesManager.setIsDeviceActive(requireContext(), false);
                    Navigation.findNavController(innerView)
                            .navigate(MainFragmentDirections.actionMainFragmentToCamera2Fragment());

                }
                for(JsonElement user : usersArray){
                    User user1 = new Gson().fromJson(user, User.class);
                    updateUserWithLocalBase(user1);
                    usersArrayList.add(user1);
                }
                invalidateLocalUsersWithRemote(preferencesManager);
                requireActivity().runOnUiThread(() -> progressBar.setVisibility(View.GONE));
            }
        });
    }


    private void getp1Username()
    {

        p1username = userlist.getSelectedItem().toString();


    }
    public void setupSSL()
    {
        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }
            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }
            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        }
        };

        try
        {

            // Install the all-trusting trust manager
            SSLContext sc = SSLContext.getInstance("SSL"); // Add in try catch block if you get error.
            sc.init(null, trustAllCerts, new java.security.SecureRandom()); // Add in try catch block if you get error.


            // Create an ssl socket factory with our all-trusting manager
            //SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
            SSLSocketFactory sslSocketFactory = sc.getSocketFactory();


            OkHttpClient.Builder builder = new OkHttpClient.Builder();

            builder.sslSocketFactory(sslSocketFactory, (X509TrustManager)trustAllCerts[0]);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });

            OkHttpClient okHttpClient = builder.build();
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }

    }

    private void pfinitiate() throws IOException
    {

        try
        {

            CookieManager cookieManager = new CookieManager();
            cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);
            OkHttpClient client = new OkHttpClient.Builder().cookieJar(new JavaNetCookieJar(cookieManager)).build();

            Request request = new Request.Builder()
                    .url("http://192.168.1.242:9032/as/authorization.oauth2?grant_type=authorization_code&response_type=code&client_id=mobileclient&scope=openid&response_mode=pi.flow&")
                    .method("GET", null)
                    .addHeader("Accept-Language", "es")
                    .build();

            try
            {
                Response response = client.newCall(request).execute();

                if (!response.headers("Set-Cookie").isEmpty())
                {
                    HashSet<String> cookies = new HashSet<>();
                    for (String header : response.headers("Set-Cookie"))
                    {
                        cookies.add(header);
                    }

                    PFCookieValue = cookies.toString();
                    PFCookieValue = PFCookieValue.substring(4,PFCookieValue.indexOf(";"));
                }

                String jdata = response.body().string();

                JSONObject jsonAsObj = new JSONObject(jdata);

                Status = jsonAsObj.getString("status");
                flowID = jsonAsObj.getString("id");

            }
            catch(Exception e)
            {

                String errorsval = e.toString();

            }
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }

    }

    void pfsubmitidentifier()
    {
        try
        {

            OkHttpClient client = new OkHttpClient().newBuilder()
                    .build();
            MediaType mediaType = MediaType.parse("application/vnd.pingidentity.submitIdentifier+json");
            RequestBody body = RequestBody.create(mediaType, "{\n\t\"identifier\": \"Native\"\n}");
            Request request = new Request.Builder()
                    .url("http://192.168.1.242:9032/pf-ws/authn/flows/"+flowID)
                    .method("POST", body)
                    .addHeader("Content-Type", "application/vnd.pingidentity.submitIdentifier+json")
                    .addHeader("X-XSRF-Header", "pingfederate")
                    .addHeader("Accept-Language", "es")
                    .addHeader("Cookie", "PF="+PFCookieValue)
                    .build();
            Response response = client.newCall(request).execute();

            String jdata = response.body().string();

            JSONObject jsonAsObj = new JSONObject(jdata);


        }
        catch (Exception e)
        {

            throw new RuntimeException(e);

        }
    }

     void pfauthenticate(String mobilePayload)
    {
        try
        {
            OkHttpClient client = new OkHttpClient().newBuilder()
                    .build();
            MediaType mediaType = MediaType.parse("application/vnd.pingidentity.authenticate+json");
            okhttp3.RequestBody body = okhttp3.RequestBody.create(mediaType, "{\n\t\"mobilePayload\": \""+mobilePayload+"\"\n}");
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url("http://192.168.1.242:9032/pf-ws/authn/flows/"+flowID)
                    .method("POST", body)
                    .addHeader("Content-Type", "application/vnd.pingidentity.authenticate+json")
                    .addHeader("X-XSRF-Header", "pingfederate")
                    //.addHeader("Cookie", "IdentityFirst.previous.subjects=UGl4ZWw1; PF=QuvUquiHMwNv6RfD08EXlCKKLI0GI9BjzPHyTShDtMX2")
                    .addHeader("Cookie", "PF="+PFCookieValue)
                    .build();
            okhttp3.Response response = client.newCall(request).execute();

            String jdata = response.body().string();

            JSONObject jsonAsObj = new JSONObject(jdata);

            Status = jsonAsObj.getString("status");

            if (!Status.equals("MFA_COMPLETED"))
            {
                pollingCheck();
            }
            else if (Status.equals("MFA_COMPLETED"))
            {
                passiveAuth.setVisibility(View.VISIBLE);

            }

        }
        catch (Exception e)
        {

        }
    }

    public void pollingCheck()
    {
        boolean mfastatus = false;


        while (!mfastatus)
        {
            flowID=flowID.trim();
            PFCookieValue=PFCookieValue.trim();

            OkHttpClient client = new OkHttpClient().newBuilder()
                    .build();
            MediaType mediaType = MediaType.parse("application/vnd.pingidentity.poll+json");
            RequestBody body = RequestBody.create(mediaType, "");
            Request request = new Request.Builder()
                    .url("http://192.168.1.242:9032/pf-ws/authn/flows/"+flowID)
                    .method("POST", body)
                    .addHeader("Content-Type", "application/vnd.pingidentity.poll+json")
                    .addHeader("X-XSRF-Header", "pingfederate")
                    .addHeader("Cookie", "PF="+PFCookieValue)
                    .build();
            try
            {

                okhttp3.Response response = client.newCall(request).execute();

                String jdata = response.body().string();

                JSONObject jsonAsObj = new JSONObject(jdata);

                String checkPoll = jsonAsObj.getString("code");

                if (checkPoll.equals("MFA_COMPLETED"))
                {
                    mfastatus=true;
                }

            }
            catch(Exception e)
            {
                throw new RuntimeException(e);

            }
        }
    }

    public void authorize()
    {

        try
        {

            mobilePayload = PingOne.generateMobilePayload(getContext());

        }
        catch (Exception e)
        {

            String errorcheck = e.toString();

        }


        if (mobilePayload != "")
        {


            try
            {

                pfinitiate();
                pfsubmitidentifier();
                pfauthenticate(mobilePayload);

            }
            catch(Exception e)
            {

                throw new RuntimeException(e);
            }

        }

    }

    @Override
    public void onResume(){
        super.onResume();
        populateOTP();
    }

    @Override
    public void onPause(){
        super.onPause();
        otpAnimationEnabled = false;
    }

    private void populateOTP() {
        otpAnimationEnabled = true;
        progressView.setPassCodeDataProvider(this);
        final ViewTreeObserver observer= progressView.getViewTreeObserver();
        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                startOtpSequence();
                progressView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });
    }

    private void populateNewButton(View view) {

        Button addNewUserButton = view.findViewById(R.id.button_new_user);
        addNewUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final NavController navController = Navigation.findNavController(view);
                NavDirections navDirections = MainFragmentDirections.actionMainFragmentToCamera2Fragment2();
                navController.navigate(navDirections);
            }
        });

    }

    private void populateSupportIdView(View view){
        PreferencesManager preferencesManager = new PreferencesManager();
        String supportIdValue = preferencesManager.getSupportId(requireActivity());
        if (supportIdValue!=null){
            TextView textView = view.findViewById(R.id.side_menu_text_view_support_id);
            textView.setText(String.format(getString(R.string.main_view_support_id_placeholder), supportIdValue));
        }
    }

    private void populateVersionView(View view) {
        TextView textView = view.findViewById(R.id.side_menu_text_view_version);
        textView.setText(String.format(getString(R.string.main_view_version_placeholder), BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE));
    }


    private void populateMenuView(View view){

        final NavigationView navView = view.findViewById(R.id.side_menu_nav_view);
        navView.bringToFront();

        ListView menuList = view.findViewById(R.id.side_menu_list);
        menuList.setItemsCanFocus(true);

        ArrayList<MenuItem> arrayList = new ArrayList<>();
        PopupMenu p  = new PopupMenu(requireContext(), view);
        Menu menu = p.getMenu();
        requireActivity().getMenuInflater().inflate(R.menu.drawer_menu, menu);
        for (int i=0; i<menu.size(); i++){
            arrayList.add(menu.getItem(i));
        }
        SideMenuAdapter adapter = new SideMenuAdapter(requireContext(), arrayList);
        menuList.setDivider(null);
        menuList.setAdapter(adapter);

        final View fragmentView = view;
        menuList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, final View view, int position, long id) {
                closeDrawer();
                if (position==0){
                    PingOne.sendLogs(requireContext(), new PingOne.PingOneSendLogsCallback() {
                        @Override
                        public void onComplete(@Nullable final String supportId, @Nullable PingOneSDKError pingOneSDKError) {
                            if(supportId!=null){
                                requireActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        new AlertDialog.Builder(requireContext())
                                                .setMessage(getString(R.string.pop_up_logs_sent_message))
                                                .setPositiveButton(getString(R.string.pop_up_logs_sent_positive_button), new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialogInterface, int i) {
                                                        dialogInterface.dismiss();
                                                    }
                                                })
                                                .create()
                                                .show();
                                        PreferencesManager preferencesManager = new PreferencesManager();
                                        preferencesManager.setSupportId(requireContext(), supportId);
                                        populateSupportIdView(fragmentView);
                                    }
                                });
                            }
                        }
                    });
                }
            }
        });
    }

    /*
     * load list of users and display them on the list view
     */
    private void populateUsersView(View view) {
        ListView userList = view.findViewById(R.id.list_view_users);
        adapter = new UsersAdapter(requireContext(), usersArrayList, this);
        userList.setAdapter(adapter);
        userList.setDivider(null);
    }

    /*
     * Prepare the error slider view to show errors in real time
     */
    private void populateErrorSliderView(View view){
        notificationSliderTextView = view.findViewById(R.id.text_notification_slider);
    }

    private void updateUserWithLocalBase(User user){
        if (localUsersArray.isEmpty() || !localUsersArray.containsKey(user.getId())){
            addRemoteUserToLocalBase(user);
        }else{
            Pair<String, String> p = localUsersArray.get(user.getId());
            if (p==null){
                p = new Pair<>("","");
            }
            if(user.getUsername()==null){
                user.setUsername(new User().new Username("", ""));
                localUsersArray.put(user.getId(), new Pair<>(p.first, ""));
            }else{
                if(!user.getUsername().getGiven().equals(p.second)){
                    localUsersArray.put(user.getId(), new Pair<>(p.first, user.getUsername().getGiven()));
                }
            }
            user.getUsername().setGiven(Objects.requireNonNull(localUsersArray.get(user.getId())).first);
            user.setNickname(Objects.requireNonNull(localUsersArray.get(user.getId())).second);
        }
    }

    private void updateLocalBaseWithEditedUser(User user){
        if (!user.getUsername().getGiven().isEmpty()) {
            localUsersArray.put(user.getId(), new Pair<>(user.getUsername().getGiven(), user.getNickname()));
        }else{
            localUsersArray.put(user.getId(), new Pair<>(user.getNickname(), user.getNickname()));
        }

    }

    /**
     * adds the user object received from the server to local array
     * @param user
     */
    private void addRemoteUserToLocalBase(User user){
        adapter.notifyDataSetChanged(user.getId());
        if (user.getUsername()==null || user.getUsername().getGiven()==null){
            user.setUsername(new User().new Username("", ""));
        }
        user.setNickname(user.getUsername().getGiven());
        localUsersArray.put(user.getId(), new Pair<>(user.getUsername().getGiven(), user.getUsername().getGiven()));
    }

    private void invalidateLocalUsersWithRemote(PreferencesManager preferencesManager){
        Iterator<Map.Entry<String, Pair<String, String>>> it = localUsersArray.entrySet().iterator();
        outer:
        while(it.hasNext()){
            Map.Entry<String, Pair<String, String>> localUser = it.next();
            for (User user : usersArrayList){
                if (localUser.getKey().equals(user.getId())){
                    continue outer;
                }
            }
            it.remove();
        }
        preferencesManager.storeUsersList(requireContext(), localUsersArray);
    }

    /*
     * open the drawer in a smooth way after hamburger pressed
     */
    private void openDrawer(){
        Runnable mPendingRunnable = new Runnable() {
            @Override
            public void run() {
                if (!mDrawerLayout.isDrawerOpen(GravityCompat.END))
                    mDrawerLayout.openDrawer(GravityCompat.END);
            }
        };
        new Handler().postDelayed(mPendingRunnable, 300);
    }

    /*
     * close the drawer in a smooth way after selecting option
     */
    private void closeDrawer() {
        Runnable mPendingRunnable = new Runnable() {
            @Override
            public void run() {
                if (mDrawerLayout.isDrawerOpen(GravityCompat.END))
                    mDrawerLayout.closeDrawer(GravityCompat.END);
            }
        };
        new Handler().postDelayed(mPendingRunnable, 300);
    }

    @Override
    public void onSave(User editedUser) {
        updateLocalBaseWithEditedUser(editedUser);
        PreferencesManager preferencesManager = new PreferencesManager();
        preferencesManager.storeUsersList(requireContext(), localUsersArray);
    }

    private void startOtpSequence(){
        if(!progressView.isWorking()){
            PingOne.getOneTimePassCode(progressView.getContext(), (otpData, error) -> {
                if(otpData!=null)
                {
                 // turn of the passive text view from silent push
                    passiveAuth.setVisibility(View.GONE);
                    progressView.updatePassCode(otpData);
                }
                else
                    {
                    progressView.setVisibility(View.INVISIBLE);
                    if(shouldRetryPasscode){
                        final Handler handler = new Handler(Looper.getMainLooper());
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                startOtpSequence();
                            }
                        }, 5000);
                        shouldRetryPasscode=false;
                    }
                }

            });
        }

    }

    @Override
    public void onPassCodeExpired() {
        if(otpAnimationEnabled){
            startOtpSequence();
        }
    }

    @Override
    public void onCopyToClipboard() {
        UserInterfaceUtil.promptMessage(progressView.getContext(), notificationSliderTextView, getString(R.string.copied));
    }

}
